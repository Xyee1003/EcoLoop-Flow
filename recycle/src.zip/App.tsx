import { useState, type ReactNode } from "react"

type IconName = "home" | "scan" | "history" | "wallet" | "chart" | "settings" | "bell" | "leaf" | "arrow" | "chevron" | "bottle" | "paper" | "glass" | "close" | "nfc" | "check" | "profile"

const iconPaths: Record<IconName, ReactNode> = {
  home: (
    <>
      <path d="m3 10 9-7 9 7" />
      <path d="M5 9v11h14V9M9 20v-6h6v6" />
    </>
  ),
  scan: (
    <>
      <path d="M4 8V4h4M16 4h4v4M20 16v4h-4M8 20H4v-4" />
      <path d="M8 12h8M12 8v8" />
    </>
  ),
  history: (
    <>
      <path d="M3 12a9 9 0 1 0 3-6.7L3 8" />
      <path d="M3 3v5h5M12 7v5l3 2" />
    </>
  ),
  wallet: (
    <>
      <path d="M4 6.5h15a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-12a2 2 0 0 1 2-2h12" />
      <path d="M16 12h5v4h-5a2 2 0 0 1 0-4Z" />
    </>
  ),
  chart: (
    <>
      <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.8 1.8 0 0 0 .36 2l.06.06-2.83 2.83-.06-.06a1.8 1.8 0 0 0-2-.36 1.8 1.8 0 0 0-1.1 1.65V21H9.83v-.09a1.8 1.8 0 0 0-1.1-1.65 1.8 1.8 0 0 0-2 .36l-.06.06-2.83-2.83.06-.06a1.8 1.8 0 0 0 .36-2 1.8 1.8 0 0 0-1.65-1.1H2V9.7h.09a1.8 1.8 0 0 0 1.65-1.1 1.8 1.8 0 0 0-.36-2l-.06-.06 2.83-2.83.06.06a1.8 1.8 0 0 0 2 .36A1.8 1.8 0 0 0 9.3 2.48V2h4v.09a1.8 1.8 0 0 0 1.1 1.65 1.8 1.8 0 0 0 2-.36l.06-.06 2.83 2.83-.06.06a1.8 1.8 0 0 0-.36 2 1.8 1.8 0 0 0 1.65 1.1H21v4h-.09a1.8 1.8 0 0 0-1.51 1.69Z" />
    </>
  ),
  bell: (
    <>
      <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" />
    </>
  ),
  leaf: (
    <>
      <path d="M20 4C11 4 5 8 5 14c0 3 2 5 5 5 6 0 10-6 10-15Z" />
      <path d="M4 21c2-6 7-10 13-13" />
    </>
  ),
  arrow: (
    <>
      <path d="M5 12h14M14 7l5 5-5 5" />
    </>
  ),
  chevron: <path d="m9 18 6-6-6-6" />,
  bottle: (
    <>
      <path d="M9 3h6M10 3v5l-2 3v9h8v-9l-2-3V3" />
      <path d="M8 13h8" />
    </>
  ),
  paper: (
    <>
      <path d="M6 3h9l4 4v14H6Z" />
      <path d="M15 3v5h4M9 13h7M9 17h5" />
    </>
  ),
  glass: (
    <>
      <path d="M8 3h8l-1 8a3 3 0 0 1-6 0ZM12 14v7M8 21h8" />
    </>
  ),
  close: (
    <>
      <path d="m6 6 12 12M18 6 6 18" />
    </>
  ),
  nfc: (
    <>
      <path d="M8 8a6 6 0 0 1 0 8M5 5a10 10 0 0 1 0 14M12 11a2 2 0 0 1 0 2" />
    </>
  ),
  check: <path d="m5 12 4 4L19 6" />,
  profile: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21a8 8 0 0 1 16 0" />
    </>
  ),
}

function Icon({ name, size = 20 }: { name: IconName size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {iconPaths[name]}
    </svg>
  )
}

const navItems: { label: string icon: IconName }[] = [
  { label: "Overview", icon: "home" },
  { label: "Smart bin", icon: "scan" },
  { label: "Activity", icon: "history" },
  { label: "Wallet", icon: "wallet" },
  { label: "My impact", icon: "chart" },
]

const materials = [
  {
    name: "Plastic",
    value: "18.4 kg",
    percent: 46,
    icon: "bottle" as IconName,
    color: "mint",
  },
  {
    name: "Paper",
    value: "13.2 kg",
    percent: 33,
    icon: "paper" as IconName,
    color: "blue",
  },
  {
    name: "Glass",
    value: "8.6 kg",
    percent: 21,
    icon: "glass" as IconName,
    color: "amber",
  },
]

const activities = [
  {
    date: "Today, 9:42 AM",
    place: "Bin EC-04 · Park Lobby",
    detail: "Plastic · Glass",
    weight: "3.2 kg",
    amount: "+ RM 5.80",
    icon: "bottle" as IconName,
    color: "mint",
  },
  {
    date: "12 Jun, 5:18 PM",
    place: "Bin EC-02 · Block A",
    detail: "Paper · Plastic",
    weight: "2.7 kg",
    amount: "+ RM 3.40",
    icon: "paper" as IconName,
    color: "blue",
  },
  {
    date: "08 Jun, 11:06 AM",
    place: "Bin EC-04 · Park Lobby",
    detail: "Glass",
    weight: "4.1 kg",
    amount: "+ RM 6.15",
    icon: "glass" as IconName,
    color: "amber",
  },
]

function App() {
  const [activeNav, setActiveNav] = useState("Overview")
  const [sessionOpen, setSessionOpen] = useState(false)
  const [sessionStep, setSessionStep] = useState<"ready" | "linked">("ready")
  const [noticeOpen, setNoticeOpen] = useState(false)

  const startSession = () => {
    setSessionStep("ready")
    setSessionOpen(true)
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">
            <Icon name="leaf" size={22} />
          </div>
          <span>EcoScan</span>
        </div>

        <nav className="main-nav" aria-label="Main navigation">
          <p className="nav-label">MAIN MENU</p>
          {navItems.map((item) => (
            <button
              className={`nav-item ${activeNav === item.label ? "active" : ""}`}
              onClick={() => setActiveNav(item.label)}
              key={item.label}
            >
              <Icon name={item.icon} />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <button className="nav-item" onClick={() => setActiveNav("Settings")}>
            <Icon name="settings" />
            <span>Settings</span>
          </button>
          <div className="profile">
            <div className="avatar">AM</div>
            <div className="profile-copy">
              <strong>Aina Malik</strong>
              <span>Residence 08-12</span>
            </div>
            <Icon name="chevron" size={17} />
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <h1>Good morning, Aina.</h1>
          </div>
          <div className="top-actions">
            <button
              className="icon-button"
              aria-label="Notifications"
              onClick={() => setNoticeOpen(!noticeOpen)}
            >
              <Icon name="profile" />
              <span className="notification-dot" />
            </button>
            <button className="start-button compact" onClick={startSession}>
              <Icon name="scan" />
              Start a session
            </button>
          </div>
          {noticeOpen && (
            <div className="notification-popover">
              <div className="notification-icon">
                <Icon name="check" size={17} />
              </div>
              <div>
                <strong>Weekly goal reached</strong>
                <p>You recycled 10.4 kg this week. Excellent work.</p>
              </div>
            </div>
          )}
        </header>

        <section className="hero-grid">
          <article className="session-card">
            <div className="session-copy">
              <div className="live-pill">
                <span /> BIN EC-04 AVAILABLE
              </div>
              <h2>
                Ready for your
                <br />
                next drop-off?
              </h2>
              <p>
                Link your account, empty your recyclables, and let EcoScan take
                care of the sorting.
              </p>
              <button className="start-button" onClick={startSession}>
                <Icon name="scan" />
                Start recycling session
                <Icon name="arrow" />
              </button>
              <span className="helper-text">Park Lobby · 2 min walk</span>
            </div>
            <div className="scanner-visual" aria-hidden="true">
              <div className="orbit orbit-one" />
              <div className="orbit orbit-two" />
              <div className="scan-rays" />
              <div className="smart-bin">
                <div className="bin-top">
                  <span />
                </div>
                <div className="bin-body">
                  <div className="bin-screen">
                    <Icon name="leaf" size={16} />
                  </div>
                  <div className="bin-slot" />
                  <div className="bin-logo">
                    <Icon name="leaf" size={13} /> ECOSCAN
                  </div>
                </div>
              </div>
              <div className="float-chip chip-plastic">
                <Icon name="bottle" size={17} />
                <span>Plastic</span>
                <strong>Valid</strong>
              </div>
              <div className="float-chip chip-paper">
                <Icon name="paper" size={17} />
                <span>Paper</span>
                <strong>Grade A</strong>
              </div>
              <div className="scan-dot dot-one" />
              <div className="scan-dot dot-two" />
            </div>
          </article>

          <article className="wallet-card">
            <div className="card-heading">
              <div>
                <p className="eyebrow">AVAILABLE BALANCE</p>
                <h3>EcoWallet</h3>
              </div>
              <div className="wallet-icon">
                <Icon name="wallet" size={21} />
              </div>
            </div>
            <div className="balance">
              <span>RM</span> 42.60
            </div>
            <div className="balance-note">
              <span>
                <Icon name="arrow" size={13} />
              </span>{" "}
              RM 15.35 earned this month
            </div>
            <button
              className="withdraw-button"
              onClick={() => setActiveNav("Wallet")}
            >
              Withdraw or pay bills <Icon name="chevron" size={16} />
            </button>
            <div className="wallet-footer">
              <span>Next auto-deduct</span>
              <strong>JMB fee · 01 Jul</strong>
            </div>
          </article>
        </section>

        <section className="stats-grid">
          <article className="impact-card">
            <div className="card-title-row">
              <div>
                <p className="eyebrow">YOUR IMPACT</p>
                <h3>Small actions, real change.</h3>
              </div>
              <button
                className="text-button"
                onClick={() => setActiveNav("My impact")}
              >
                View report <Icon name="arrow" size={15} />
              </button>
            </div>
            <div className="impact-content">
              <div className="impact-ring">
                <svg viewBox="0 0 120 120">
                  <circle className="ring-bg" cx="60" cy="60" r="48" />
                  <circle
                    className="ring-progress"
                    cx="60"
                    cy="60"
                    r="48"
                    pathLength="100"
                  />
                </svg>
                <div className="ring-value">
                  <strong>40.2</strong>
                  <span>kg diverted</span>
                </div>
              </div>
              <div className="impact-metrics">
                <div>
                  <span className="metric-icon">
                    <Icon name="leaf" size={18} />
                  </span>
                  <p>
                    <strong>12.8 kg</strong>
                    <small>CO₂ emissions avoided</small>
                  </p>
                </div>
                <div>
                  <span className="metric-icon water">≈</span>
                  <p>
                    <strong>284 L</strong>
                    <small>Water saved</small>
                  </p>
                </div>
              </div>
            </div>
            <div className="goal-row">
              <div>
                <strong>June goal</strong>
                <span>40.2 of 50 kg</span>
              </div>
              <div className="progress">
                <span />
              </div>
            </div>
            {materials.map((material) => (
              <div className="material-row" key={material.name}>
                <span className={`material-icon ${material.color}`}>
                  <Icon name={material.icon} size={18} />
                </span>
                <div className="material-info">
                  <div>
                    <strong>{material.name}</strong>
                    <span>{material.value}</span>
                  </div>
                  <div className="material-progress">
                    <span
                      className={material.color}
                      style={{ width: `${material.percent}%` }}
                    />
                  </div>
                </div>
                <small>{material.percent}%</small>
              </div>
            ))}
          </article>
        </section>

        <section className="activity-card">
          <div className="card-title-row">
            <div>
              <p className="eyebrow">RECENT ACTIVITY</p>
              <h3>Your recycling log</h3>
            </div>
            <button
              className="text-button"
              onClick={() => setActiveNav("Activity")}
            >
              View all <Icon name="arrow" size={15} />
            </button>
          </div>
          <div className="activity-table">
            {activities.map((activity) => (
              <div className="activity-row" key={activity.date}>
                <span className={`material-icon ${activity.color}`}>
                  <Icon name={activity.icon} size={19} />
                </span>
                <div className="activity-main">
                  <strong>{activity.place}</strong>
                  <span>{activity.date}</span>
                </div>
                <div className="activity-detail">
                  <strong>{activity.detail}</strong>
                  <span>AI verified</span>
                </div>
                <strong className="weight">{activity.weight}</strong>
                <strong className="amount">{activity.amount}</strong>
                <button
                  className="row-button"
                  aria-label={`View activity from ${activity.date}`}
                >
                  <Icon name="chevron" size={16} />
                </button>
              </div>
            ))}
          </div>
        </section>
      </main>

      <nav className="mobile-nav" aria-label="Mobile navigation">
        {navItems.slice(0, 4).map((item) => (
          <button
            className={activeNav === item.label ? "active" : ""}
            onClick={() => setActiveNav(item.label)}
            key={item.label}
          >
            <Icon name={item.icon} size={21} />
            <span>{item.label === "Smart bin" ? "Scan" : item.label}</span>
          </button>
        ))}
      </nav>

      {sessionOpen && (
        <div
          className="modal-backdrop"
          role="presentation"
          onMouseDown={() => setSessionOpen(false)}
        >
          <section
            className="session-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="session-title"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <button
              className="modal-close"
              aria-label="Close"
              onClick={() => setSessionOpen(false)}
            >
              <Icon name="close" />
            </button>
            {sessionStep === "ready" ? (
              <>
                <div className="modal-icon">
                  <Icon name="nfc" size={28} />
                </div>
                <p className="eyebrow">BIN EC-04 · PARK LOBBY</p>
                <h2 id="session-title">Link your account</h2>
                <p className="modal-description">
                  Hold your phone near the NFC reader, or use your personal QR
                  code to unlock the tray.
                </p>
                <div className="qr-code" aria-label="Personal QR code">
                  {Array.from({ length: 64 }, (_, index) => (
                    <i
                      key={index}
                      className={
                        (index * 7 + (index % 3)) % 5 < 2 ? "filled" : ""
                      }
                    />
                  ))}
                </div>
                <button
                  className="start-button modal-action"
                  onClick={() => setSessionStep("linked")}
                >
                  Simulate NFC link <Icon name="arrow" />
                </button>
              </>
            ) : (
              <div className="linked-state">
                <div className="success-check">
                  <Icon name="check" size={32} />
                </div>
                <p className="eyebrow">ACCOUNT LINKED</p>
                <h2 id="session-title">Tray unlocked</h2>
                <p className="modal-description">
                  Empty your dry recyclables onto the tray. EcoScan will spread,
                  inspect, and weigh each item.
                </p>
                <div className="live-status">
                  <span className="pulse" />
                  <div>
                    <strong>Waiting for items</strong>
                    <small>Live camera and weight sensors are ready</small>
                  </div>
                </div>
                <button
                  className="withdraw-button modal-action"
                  onClick={() => setSessionOpen(false)}
                >
                  Done
                </button>
              </div>
            )}
          </section>
        </div>
      )}
    </div>
  )
}

export default App
